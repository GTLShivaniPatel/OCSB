import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IndexComponent } from './components/index/index.component';
import { AboutComponent } from './components/shared/about/about.component';
import { ContactComponent } from './components/shared/contact/contact.component';
import { PagenotfoundComponent } from './components/shared/pagenotfound/pagenotfound.component';
import { AuthGuard } from './shared/auth/auth.guard';
import { VerificationComponent } from './modules/service/verification/verification.component';
import { VehicleselectionComponent } from './modules/service/vehicleselection/vehicleselection.component';
import { ServiceselectionComponent } from './modules/service/serviceselection/serviceselection.component';
import { DealerselectionComponent } from './modules/service/dealerselection/dealerselection.component';
import { AppointmentbookingComponent } from './modules/service/appointmentbooking/appointmentbooking.component';
import { AppointmentconfirmComponent } from './modules/service/appointmentconfirm/appointmentconfirm.component';


const routes: Routes = [
  {
    path: '',
    redirectTo: 'index',
    pathMatch: 'full'
  },
  {
    path: 'index',
    component: IndexComponent
  },
  {
    path: 'service',
    loadChildren: () => import('./modules/service/service.module')
      .then(m => m.ServiceModule)
  },
  {
    path: 'services',
    component: VerificationComponent
  },
  {
    path: 'verification',
    component: VerificationComponent
  },
  {
    path: 'vehicleSelection/:Email',
    component: VehicleselectionComponent
  },
  {
    path: 'serviceSelection/:id',
    component: ServiceselectionComponent
  },
  {
    path:'dealerSelection',
    component: DealerselectionComponent
  },
  {
    path:'appointmentbooking',
    component: AppointmentbookingComponent
  },
  {
    path: 'appointmentconfirm',
    component: AppointmentconfirmComponent
  },
  {
    path: 'contact',
    component: ContactComponent
  },
  {
    path: 'about',
    component: AboutComponent
  },
  {
    path: '**',
    component: PagenotfoundComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
