export class Api {
}
export const baseUrl = 'https://localhost:44364/api'
export const sendOtpUrl = baseUrl + '/Authentication/SendOTP'
export const verifyOtpUrl = baseUrl + '/Authentication/VerifyOTP'
export const vehicleListUrl = baseUrl + '/Vehicle'
export const getCustomerUrl = baseUrl + '/Customer'
export const getServiceGroupUrl = baseUrl + '/Service/Group'
export const getServicesUrl = baseUrl + '/Service'
export const getDealerUrl = baseUrl + '/Dealer'
export const getAvailabilityUrl = baseUrl + '/Dealer/GetAvalibility'
export const bookAppointmentUrl = baseUrl + '/Appointment/Add'