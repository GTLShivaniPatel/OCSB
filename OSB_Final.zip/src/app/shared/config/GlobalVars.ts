export class GlobalVars {
    static userEmail: string = "";
    static customerName: string = "";
    static licensePlateNumber: string = "";
    static vehicleId: number = 0;
    static fuelTypeId: number = 0;
    static selectedService: Array<{id: number}> = [];
    static serviceDuration : number = 0;
    static PreferredDealerId: number = 0;
    static dealerId: number = 0;
    static planDateTime: string = "";
    static appointmentId;
  }
  // export type selectedService = Array<{id: number}>;
  // export const abc = Object.freeze({});
// export const selectedService = [];