import { Injectable } from '@angular/core';
import { HttpHeaders, HttpParams, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { getServiceGroupUrl, getServicesUrl } from '../config/api';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  constructor
  (
    private httpclient: HttpClient
  ) { }

  httpOptions = {
    headers: new HttpHeaders({ 
      'Content-Type': 'application/json'
    })
  };

  getHeader()
  {
    var auth = ("b3NiOmFkbWluQG9zYkAxMjM="), 
    headers = {"Authorization": "Basic " + auth};
    return headers;
  }

  getServiceGroup(): Observable<any> {
    return this.httpclient.get<any>(`${getServiceGroupUrl}`,{ headers : this.getHeader() });
  }

  getServices(fuelTypeId): Observable<any> {
    let params = new HttpParams().set("fuelTypeId",fuelTypeId);
    //console.log(params);
    return this.httpclient.get<any>(`${getServicesUrl}`,{ params: params, headers : this.getHeader() });
  }
}