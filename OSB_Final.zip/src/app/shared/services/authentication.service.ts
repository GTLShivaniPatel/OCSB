import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpParams, HttpHeaders, HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { sendOtpUrl, verifyOtpUrl } from '../config/api';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor
  (
    private httpclient: HttpClient
  ) { }

  httpOptions = {
    headers: new HttpHeaders({ 
      'Content-Type': 'application/json'
      //, 'Authorization': 'Basic ' + btoa('osb:admin@osb@123')
    })
  };

  getHeader()
  {
    var auth = ("b3NiOmFkbWluQG9zYkAxMjM="), 
    headers = {"Authorization": "Basic " + auth};
    return headers;
  }

  getUser(email): Observable<any> {
    let params = new HttpParams().set('email', email);
    //console.log(params);
    return this.httpclient.get<any>(`${sendOtpUrl}`,{ params: params, headers : this.getHeader() });
  }

  verifyOtp(email, otp): Observable<any> {
    let params = new HttpParams().set("email",email).append("otp",otp);
    //console.log(params);
    return this.httpclient.get<any>(`${verifyOtpUrl}`,{ params: params, headers : this.getHeader() });
  }
}