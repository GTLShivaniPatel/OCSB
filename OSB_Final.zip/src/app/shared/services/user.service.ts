import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { getCustomerUrl } from '../config/api';
import { Customer } from '../models/customer';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor
  (
    private httpclient: HttpClient
  ) { }

  httpOptions = {
    headers: new HttpHeaders({ 
      'Content-Type': 'application/json'
    })
  };

  getHeader()
  {
    var auth = ("b3NiOmFkbWluQG9zYkAxMjM="), 
    headers = {"Authorization": "Basic " + auth};
    return headers;
  }

  getUser(email): Observable<Customer> {
    let params = new HttpParams().set('email', email);
    //console.log(params);
    return this.httpclient.get<Customer>(`${getCustomerUrl}`,{ params: params, headers : this.getHeader() });
  }
}
