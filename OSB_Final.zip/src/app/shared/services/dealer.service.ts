import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { getDealerUrl, getAvailabilityUrl } from '../config/api';

@Injectable({
  providedIn: 'root'
})
export class DealerService {

  constructor
  (
    private httpclient: HttpClient,
    private router: Router
  ) { }

  httpOptions = {
    headers: new HttpHeaders({ 
      'Content-Type': 'application/json'
      //, 'Authorization': 'Basic ' + btoa('osb:admin@osb@123')
    })
  };

  getHeader()
  {
    var auth = ("b3NiOmFkbWluQG9zYkAxMjM="), 
    headers = {"Authorization": "Basic " + auth};
    return headers;
  }

  getDealers(): Observable<any> {
    return this.httpclient.get<any>(`${getDealerUrl}`,{ headers : this.getHeader() });
  }

  getAvalibility(dealerId, serviceDuration): Observable<any> {
    let params = new HttpParams().set("dealerId",dealerId).append("serviceDuration",serviceDuration);
    console.log(params);
    return this.httpclient.get<any>(`${getAvailabilityUrl}`,{ params: params, headers : this.getHeader() });
  }
}
