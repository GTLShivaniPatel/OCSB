import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { bookAppointmentUrl } from '../config/api';
import { Booking } from '../models/booking';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  constructor
  (
    private httpclient: HttpClient
  ) { }

  httpOptions = {
    headers: new HttpHeaders({ 
      'Content-Type': 'application/json'
      //, 'Authorization': 'Basic ' + btoa('osb:admin@osb@123')
    })
  };

  getHeader()
  {
    var auth = ("b3NiOmFkbWluQG9zYkAxMjM="), 
    headers = {"Authorization": "Basic " + auth};
    return headers;
  }

  bookAppointment(booking): Observable<Booking> {
    return this.httpclient.post<Booking>(`${bookAppointmentUrl}`,booking, {headers: this.getHeader()});
  }
}
