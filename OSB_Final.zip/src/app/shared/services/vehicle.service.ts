import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { vehicleListUrl } from '../config/api';

@Injectable({
  providedIn: 'root'
})
export class VehicleService {

  constructor
  (
    private httpclient: HttpClient
  ) { }

  httpOptions = {
    headers: new HttpHeaders({ 
      'Content-Type': 'application/json'
    })
  };

  getHeader()
  {
    var auth = ("b3NiOmFkbWluQG9zYkAxMjM="), 
    headers = {"Authorization": "Basic " + auth};
    return headers;
  }

  getVehicleList(id): Observable<any> {
    let params = new HttpParams().set('id', id);
    //console.log(params);
    return this.httpclient.get<any>(`${vehicleListUrl}`,{ params: params, headers : this.getHeader() });
  }
}
