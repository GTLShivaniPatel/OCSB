export class Vehicle {
    VehicleId: number;
    LicensePlateNumber: string;
    FuelTypeId: number;
    BrandId: number;
    BrandImagePath: string;
    BrandName: number;
    ModelId: number;
    ModelName: string;
    isSelected: boolean;
    constructor(
        VehicleId: number,
        LicensePlateNumber: string,
        FuelTypeId: number,
        BrandId: number,
        ModelId: number,
        BrandName: number,
        BrandImagePath: string,
        ModelName: string,
        isSelected: boolean
    ) {
        VehicleId = this.VehicleId;
        LicensePlateNumber = this.LicensePlateNumber;
        FuelTypeId = this.FuelTypeId;
        BrandId = this.BrandId;
        BrandImagePath = this.BrandImagePath;
        BrandName = this.BrandName;
        ModelId = this.ModelId;
        ModelName = this.ModelName;
        isSelected = this.isSelected;
    }
}