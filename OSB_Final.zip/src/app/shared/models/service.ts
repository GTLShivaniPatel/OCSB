export class Service {
    ServiceId: number;
    ServiceGroupServiceGroupId: number;
    ServiceGroupServiceGroupeName: string;
    Name: string;
    Cost: number;
    Duration: number;
    FuelType: number;
    ServiceDetailModels: any;
    IsChecked: boolean;
    constructor(
        ServiceId: number,
        Name: string,
        Cost: number,
        ServiceGroupServiceGroupId: number,
        ServiceGroupServiceGroupeName: string,
        Duration: number,
        FuelType: number,
        ServiceDetailModels: any,
        IsChecked: boolean
    ) {
        ServiceId = this.ServiceId;
        Name = this.Name;
        Cost = this.Cost;
        ServiceGroupServiceGroupId = this.ServiceGroupServiceGroupId;
        ServiceGroupServiceGroupeName = this.ServiceGroupServiceGroupeName;
        Duration = this.Duration;
        FuelType = this.FuelType;
        ServiceDetailModels = this.ServiceDetailModels;
        IsChecked = this.IsChecked;
    }
}
