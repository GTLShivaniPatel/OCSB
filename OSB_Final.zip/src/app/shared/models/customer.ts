export class Customer {
    CustomerId: number;
    Name: string;
    ContactNo: string;
    EmailId: string;
    Address: string;
    PreferredDealerId: number;
    constructor(
        CustomerId: number,
        Name: string,
        ContactNo: string,
        EmailId: string,
        Address: string,
        PreferredDealerId: number
    ) {
        CustomerId = this.CustomerId;
        Name = this.Name;
        ContactNo = this.ContactNo;
        EmailId = this.EmailId;
        Address = this.Address;
        PreferredDealerId = this.PreferredDealerId;
    }
}
