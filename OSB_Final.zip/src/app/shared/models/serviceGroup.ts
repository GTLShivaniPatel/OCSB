export class ServiceGroup {
    ServiceGroupId: number;
    ServiceGroupeName: string;
    constructor(
        ServiceGroupId: number,
        ServiceGroupeName: string
    ) {
        ServiceGroupId = this.ServiceGroupId;
        ServiceGroupeName = this.ServiceGroupeName;
    }
}