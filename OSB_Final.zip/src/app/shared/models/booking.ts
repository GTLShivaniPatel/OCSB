export class Booking {
    ContactPersonName: string;
    ContactNumber: string;
    PickUpAddress: string;
    DropAddress: string;
    LicensePlateNumber: string;
    PlanDateTime: string;
    CustomerName: string;
    VehicleId: number;
    DealerId: number;
    CustomerEmail: string;
    CustomerNote: string;
    SelectedServices;

    constructor(
        ContactPersonName: string,
        ContactNumber: string,
        PickUpAddress: string,
        DropAddress: string,
        LicensePlateNumber: string,
        PlanDateTime: string,
        CustomerName: string,
        VehicleId: number,
        DealerId: number,
        CustomerEmail: string,
        CustomerNote: string,
        SelectedServices
    ) {
        ContactPersonName = this.ContactPersonName;
        ContactNumber = this.ContactNumber;
        PickUpAddress = this.PickUpAddress;
        DropAddress = this.DropAddress;
        LicensePlateNumber = this.LicensePlateNumber;
        PlanDateTime = this.PlanDateTime;
        CustomerName = this.CustomerName;
        VehicleId = this.VehicleId;
        DealerId = this.DealerId;
        CustomerEmail = this.CustomerEmail;
        CustomerNote = this.CustomerNote;
        SelectedServices = this.SelectedServices;
    }
}
