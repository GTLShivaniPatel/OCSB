export class Dealer {
    DealerId: number;
    Name: string;
    ContactNo: string;
    EmailId: string;
    Address: string;
    constructor(
        DealerId: number,
        Name: string,
        ContactNo: string,
        EmailId: string,
        Address: string
    ) {
        DealerId = this.DealerId;
        Name = this.Name;
        ContactNo = this.ContactNo;
        EmailId = this.EmailId;
        Address = this.Address;
    }
}
