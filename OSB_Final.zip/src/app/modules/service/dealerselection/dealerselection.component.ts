import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GlobalVars } from 'src/app/shared/config/GlobalVars';
import { DealerService } from 'src/app/shared/services/dealer.service';
import { NgbDateStruct, NgbCalendar, NgbDatepickerConfig } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { DatePipe } from '@angular/common';
import { Dealer } from 'src/app/shared/models/dealer';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker/public_api';

@Component({
  selector: 'app-dealerselection',
  templateUrl: './dealerselection.component.html',
  styleUrls: ['./dealerselection.component.css']
})

export class DealerselectionComponent implements OnInit {

  bsInlineValue;
  model: NgbDateStruct;
  date: { year: number, month: number };
  dealerList: Array<Dealer> = [];
  selectedDealer: number;
  PreferredDealerId: number;
  planDate: string = "2020-07-29";
  toDate: NgbDateStruct;
  radioSelected: any;
  disabledDates = [];
  isDealerSelected: boolean = false;
  date1: Date;
  datePickerConfig: Partial<BsDatepickerConfig>;
  minDate= {year:new Date().getFullYear(), month: new Date().getMonth(), day: new Date().getDay() + 22};
  maxDate= {year: new Date().getFullYear(), month: new Date().getMonth(), day: new Date().getDay() + 39};

  constructor
    (
      private route: ActivatedRoute,
      public router: Router,
      private dealerService: DealerService,
      private calendar: NgbCalendar,
      private toastrService: ToastrService,
      public datepipe: DatePipe
    ) {
      this.date1 = new Date();
    this.datePickerConfig = Object.assign({},
      {
        containerClass: 'theme-dark-blue',
        showWeeknumbers: false,
        minDate: new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDay() + 22),
        maxDate: new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDay() + 39),
        dateInputFormat: 'DD/MM/YYYY',
        showWeekNumbers: false,
        daysDisabled: [6, 0]
      });
  }


  ngOnInit(): void {
    this.getDealers();
    this.PreferredDealerId = GlobalVars.PreferredDealerId;
    this.selectedDealer = GlobalVars.PreferredDealerId;
    GlobalVars.dealerId = GlobalVars.PreferredDealerId;
  }

  getDealers() {
    this.PreferredDealerId = GlobalVars.PreferredDealerId;
    //console.log("PreferredDealerId in get Dealers :", this.PreferredDealerId)
    this.dealerService.getDealers()
      .subscribe(
        data => {
          if (data) {
            data.forEach(element => {
              this.dealerList.push(element);
              //console.log("dealer list Data : ", this.dealerList);
            })
            if (GlobalVars.PreferredDealerId != 0) {
              this.isDealerSelected = true;
              this.getAvalibility();
              this.toastrService.success("Your Preferred Dealer is selected!");
            }
          }
        }
      )
  }

  onDealerSelection(e, dealerId) {
    if (e.target.checked) {
      this.isDealerSelected = true;
      this.selectedDealer = dealerId;
      GlobalVars.dealerId = dealerId;
      console.log("on Change Dealer Id : ", this.selectedDealer);
      this.getAvalibility();
    }
  }

  getAvalibility() {
    this.dealerService.getAvalibility(this.selectedDealer, GlobalVars.serviceDuration)
      .subscribe(
        data => {
          if (data) {
            this.disabledDates = data;
            this.disableDates(data);
          }
        }
      )
  }

  disableDates(dates) {
    dates.forEach(element => {
      console.log("Disabled element : ", element.substring(0, 10));
      this.disabledDates.push(
        new Date(element.substring(0, 10))
      )
    });
  }

  changeValue() {
    console.log("On value change! ")
  }

  onDateValueChange(e) {
    console.log("event : ",e);
    // console.log("Date ", date, "Date ", date.day, "Month ", date.month, "Year ", date.year);
    // this.planDate = date.year.toString().concat("-").concat(date.month.toString()).concat("-").concat(date.day.toString());
    // this.planDate = "2020-07-29";
    // console.log("plan date : ", this.planDate);
  }

  onNextClick() {
    GlobalVars.planDateTime = this.planDate;
    this.router.navigate(['/appointmentbooking'])
  }

  goToVehicleSelection() {
    this.router.navigate(['vehicleSelection', GlobalVars.userEmail])
  }

  goToServiceSelection() {
    //console.log("go to service selection called and fuel type id is : " + GlobalVars.fuelTypeId);
    this.router.navigate(['serviceSelection', GlobalVars.fuelTypeId])
  }
}