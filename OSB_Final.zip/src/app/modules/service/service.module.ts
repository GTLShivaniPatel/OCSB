import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { ServiceComponent } from './service/service.component';
import { ServiceRoutingModule } from './service-routing.module';
import { FormsModule } from '@angular/forms';
import { VerificationComponent } from './verification/verification.component';
import { VehicleselectionComponent } from './vehicleselection/vehicleselection.component';
import { HighLightDirective } from './vehicleselection/high-light.directive';
import { ServiceselectionComponent } from './serviceselection/serviceselection.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DealerselectionComponent } from './dealerselection/dealerselection.component';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxSpinnerModule } from "ngx-spinner";
import { AppointmentbookingComponent } from './appointmentbooking/appointmentbooking.component';
import { AppointmentconfirmComponent } from './appointmentconfirm/appointmentconfirm.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';

@NgModule({
  declarations: [ServiceComponent, VerificationComponent, VehicleselectionComponent, HighLightDirective, ServiceselectionComponent, DealerselectionComponent, AppointmentbookingComponent, AppointmentconfirmComponent],
  imports: [
    CommonModule,
    ServiceRoutingModule,
    FormsModule,
    NgbModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    NgxSpinnerModule,
    BsDatepickerModule.forRoot()
  ],
  providers: [DatePipe]
})
export class ServiceModule { }
