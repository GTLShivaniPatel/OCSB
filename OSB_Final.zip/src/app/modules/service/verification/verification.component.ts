import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/shared/services/auth.service';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/shared/services/authentication.service';
import { GlobalVars } from 'src/app/shared/config/GlobalVars';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-verification',
  templateUrl: './verification.component.html',
  styleUrls: ['./verification.component.css']
})
export class VerificationComponent implements OnInit {

  constructor
    (
      public authService: AuthService,
      public router: Router,
      private authenticationService: AuthenticationService,
      private toastrService: ToastrService,
      private spinnerService: NgxSpinnerService
    ) { }

  email: string;
  otp: number;
  isEmailExists: boolean = false;
  isOtpVerified: boolean = false;

  ngOnInit(): void {
    GlobalVars.userEmail = "";
    this.spinnerService.show();

    setTimeout(() => {
      /** spinner ends after 5 seconds */
      this.spinnerService.hide();
    }, 300);
  }

  getUser() {
    console.log("entered email : " + this.email)
    if (this.email) {
      this.spinnerService.show();
      setTimeout(() => {
        this.spinnerService.hide();
      }, 3000);
      this.authenticationService.getUser(this.email)
        .subscribe(
          data => {
            if (data === "s_1111") {
              this.isEmailExists = true;
              this.toastrService.success("Otp is sent to your Email" + " " + this.email + " " + "Successfully!");
            }
            else {
              this.isEmailExists = false;
              this.toastrService.error("Your Email is not Registered! Contact your Dealer!");
            }
          }
        )
    }
    else {
      this.toastrService.error("Enter Email to get OTP!");
    }
  }

  verifyOtp() {
    console.log("otp " + this.otp);
    if (this.otp) {
      this.spinnerService.show();
      setTimeout(() => {
        this.spinnerService.hide();
      }, 1000);
      this.authenticationService.verifyOtp(this.email, this.otp)
        .subscribe(
          data => {
            if (data === "s_1112") {
              this.isOtpVerified = true;
              this.toastrService.success("Otp is verified Successfully!" + " " + "Select Your Vehicle to proceed further.");
              this.router.navigate(['vehicleSelection', this.email])
              GlobalVars.userEmail = this.email;
            }
            else if (data === "e_1112") {
              this.toastrService.error("OTP is valid but Expired! Try Again!");
              this.router.navigate(['index'])
            }
            else if (data === "e_1113") {
              this.toastrService.error("OTP is not Valid!");
            }
            else if (data === "e_1114") {
              this.toastrService.error("Entered Email is not Registerd!");
            }
          }
        )
    }
    else {
      this.toastrService.error("Enter OTP!");
    }
  }

  verify() {

    this.authService.login().subscribe(() => {
      console.log("In Verify 1");
      if (this.authService.isLoggedIn) {
        const redirectUrl = '/about';

        this.router.navigate([redirectUrl]);
        console.log("In Verify 2");
      }
    });
  }

}
