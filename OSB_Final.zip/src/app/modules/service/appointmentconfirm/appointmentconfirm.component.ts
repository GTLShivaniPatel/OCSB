import { Component, OnInit } from '@angular/core';
import { GlobalVars } from 'src/app/shared/config/GlobalVars';

@Component({
  selector: 'app-appointmentconfirm',
  templateUrl: './appointmentconfirm.component.html',
  styleUrls: ['./appointmentconfirm.component.css']
})
export class AppointmentconfirmComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  appointmentId : number = GlobalVars.appointmentId;

}
