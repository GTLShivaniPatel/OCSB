import { Component, OnInit } from '@angular/core';
import { GlobalVars } from 'src/app/shared/config/GlobalVars';
import { Router } from '@angular/router';
import { Booking } from 'src/app/shared/models/booking';
import { BookingService } from 'src/app/shared/services/booking.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-appointmentbooking',
  templateUrl: './appointmentbooking.component.html',
  styleUrls: ['./appointmentbooking.component.css']
})
export class AppointmentbookingComponent implements OnInit {

  constructor
    (
      public router: Router,
      private bookingService: BookingService,
      private spinnerService: NgxSpinnerService
    ) { }

  isPickUp: boolean = false;
  isDrop: boolean = false;
  mobilenumberpattern = "^((\\+91-?)|0)?[0-9]{10}$";

  book: Booking = {
    ContactNumber: null,
    DropAddress: null,
    ContactPersonName: null,
    PickUpAddress: null,
    CustomerEmail: GlobalVars.userEmail,
    CustomerName: GlobalVars.customerName,
    CustomerNote: null,
    DealerId: GlobalVars.dealerId,
    LicensePlateNumber: GlobalVars.licensePlateNumber,
    PlanDateTime: GlobalVars.planDateTime,
    SelectedServices: GlobalVars.selectedService,
    VehicleId: GlobalVars.vehicleId
  }

  ngOnInit(): void {
    GlobalVars.appointmentId = 0;
  }

  bookAppointment() {
    this.spinnerService.show();
    setTimeout(() => {
      /** spinner ends after 5 seconds */
      this.spinnerService.hide();
    }, 3000);
    //this.book.PlanDateTime = "2020-07-21";
    console.log("book appointment function called : ",this.book);
    this.bookingService.bookAppointment(this.book)
      .subscribe(
        data => {
          console.log("data from post appointment : ", data);
          GlobalVars.appointmentId = data;
          this.router.navigate(['/appointmentconfirm'])
        }
      );
  }

  goToVehicleSelection() {
    this.router.navigate(['vehicleSelection', GlobalVars.userEmail])
  }

  goToServiceSelection() {
    this.router.navigate(['serviceSelection', GlobalVars.fuelTypeId])
  }

  goToDealerSelection() {
    this.router.navigate(['/dealerSelection'])
  }
}
