import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ServiceService } from 'src/app/shared/services/service.service';
import { GlobalVars } from 'src/app/shared/config/GlobalVars';
import { ToastrService } from 'ngx-toastr';
import { ServiceGroup } from 'src/app/shared/models/serviceGroup';
import { Service } from 'src/app/shared/models/service';

@Component({
  selector: 'app-serviceselection',
  templateUrl: './serviceselection.component.html',
  styleUrls: ['./serviceselection.component.css']
})
export class ServiceselectionComponent implements OnInit {

  constructor
    (
      private route: ActivatedRoute,
      public router: Router,
      private getServiceSrevice: ServiceService,
      private toastrService: ToastrService
    ) { }

  ngOnInit(): void {
    this.getServiceGroups();
    GlobalVars.selectedService = [];
    GlobalVars.serviceDuration = 0;
    this.serviceTotal = 0;
  }

  serviceGroupList: Array<ServiceGroup> = [];
  servicesList: Array<Service> = [];
  serviceTotal: number;
  selectedServices: Array<{"serviceId": number, "servicename": string, "serviceCost": number, "serviceDuration": number}> = [];

  getServiceGroups() {
    const fuelTypeId = this.route.snapshot.paramMap.get('id');
    this.getServiceSrevice.getServiceGroup()
      .subscribe(
        data => {
          if (data) {
            data.forEach(element => {
              this.serviceGroupList.push(element);
            })
            this.getServices(fuelTypeId);
          }
        }
      )
  }

  getServices(fuelTypeId) {
    this.getServiceSrevice.getServices(fuelTypeId)
      .subscribe(
        data => {
          if (data) {
            data.forEach(element => {
              element.IsChecked = false;
              this.servicesList.push(element);
            })
          }
        }
      )
  }

  changeService(e, serviceId) {
    if(e.target.checked) {
      this.servicesList.find(x => x.ServiceId === serviceId).IsChecked = true;
      this.selectedServices.push({
        "serviceId" : serviceId,
        "servicename" : this.servicesList.find(x => x.ServiceId === serviceId).Name,
        "serviceDuration" : this.servicesList.find(x => x.ServiceId === serviceId).Duration,
        "serviceCost" : this.servicesList.find(x => x.ServiceId === serviceId).Cost
      });
      GlobalVars.selectedService.push(serviceId);
      this.toastrService.success("Service" + " " + (this.servicesList.find(x => x.ServiceId === serviceId)).Name + " " + "added to Services List Successfully!");
      GlobalVars.serviceDuration += (this.servicesList.find(x => x.ServiceId === serviceId)).Duration;
      this.serviceTotal += this.servicesList.find(x => x.ServiceId == serviceId).Cost;
    }
    else {
      this.removeService(serviceId);
    }
  }

  removeService(serviceId) {
    this.servicesList.find(x => x.ServiceId === serviceId).IsChecked = false;
    const index: number = GlobalVars.selectedService.indexOf(serviceId);
    if (index !== -1) {
      this.selectedServices.splice(index, 1);
      GlobalVars.selectedService.splice(index, 1);
      GlobalVars.serviceDuration -= this.servicesList.find(x => x.ServiceId == serviceId).Duration;
      this.toastrService.success("Service" + " " + this.servicesList.find(x => x.ServiceId === serviceId).Name + " " + "Removed from Services List Successfully!");
      this.serviceTotal -= this.servicesList.find(x => x.ServiceId == serviceId).Cost;
  }
}

  onNextClick() {
    this.router.navigate(['/dealerSelection'])
  }

  goToVehicleSelection() {
    this.router.navigate(['vehicleSelection', GlobalVars.userEmail])
  }
}
