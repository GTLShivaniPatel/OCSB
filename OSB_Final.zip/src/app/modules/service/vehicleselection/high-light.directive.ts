import { Directive, ElementRef, HostListener, Input, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appHighLight]'
})
export class HighLightDirective {

  constructor(private e : ElementRef, private renderer: Renderer2) {
    // e.nativeElement.style.backgroundColor = 'green';
  }
  @Input('appHighlight') highlightColor: string;

  @HostListener('click', ['$event'])
  changeBackground(): void {
    this.renderer.setStyle(event.target, 'background', 'skyblue');
  }

  @HostListener('mouseenter') onmouseenter()
  {
    this.highlight(null);
  }
  @HostListener('mouseleave') onmouseleave()
  {
    this.highlight(null);
  }
  // @HostListener('click') onmouseclick()
  // {
  //   this.highlight('lightgreen');
  // }
 
  private highlight(color : string)
  {
    this.e.nativeElement.style.backgroundColor = color;
  }

}
