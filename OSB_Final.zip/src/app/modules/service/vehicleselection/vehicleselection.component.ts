import { Component, OnInit } from '@angular/core';
import { VehicleService } from 'src/app/shared/services/vehicle.service';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/shared/services/user.service';
import { Vehicle } from 'src/app/shared/models/vehicle';
import { GlobalVars } from 'src/app/shared/config/GlobalVars';
import { Customer } from 'src/app/shared/models/customer';

@Component({
  selector: 'app-vehicleselection',
  templateUrl: './vehicleselection.component.html',
  styleUrls: ['./vehicleselection.component.css']
})
export class VehicleselectionComponent implements OnInit {

  constructor
    (
      public router: Router,
      private vehicleService: VehicleService,
      private userService: UserService,
      private route: ActivatedRoute
    ) { }

  ngOnInit(): void {
    GlobalVars.PreferredDealerId = 0;
    GlobalVars.customerName = "";
    GlobalVars.fuelTypeId = 0;
    GlobalVars.licensePlateNumber = "";
    GlobalVars.vehicleId = 0;
    this.getUserId();
  }

  user: Array<Customer> = [];
  vehicleList: Array<Vehicle> = [];
  isVehicleFound: boolean = false;
  selectedVehicle: Vehicle;
  fuelTypeId: number;

  getUserId() {
    const email = this.route.snapshot.paramMap.get('Email');
    this.userService.getUser(email)
      .subscribe(
        data => {
          if (data != null) {
            GlobalVars.PreferredDealerId = data.PreferredDealerId;
            console.log("preferred Dealer : ",GlobalVars.PreferredDealerId);
            GlobalVars.customerName = data.Name;
            if (data.CustomerId != null) {
              this.user.push(data);
              this.getVehicleList(data.CustomerId);
            }
          }
          else {
          }
        }
      )
  }

  getVehicleList(customerId) {
    //console.log("in Vehicle List Section ")
    this.vehicleService.getVehicleList(customerId)
      .subscribe(
        data => {
          if (data != null) {
            this.isVehicleFound = true;
            //console.log("Vehicle Data : " + JSON.stringify(data));
            data.forEach(element => {
              this.vehicleList.push(element);
            })
            //console.log("Vehicle data in Array : " + JSON.stringify(this.vehicleList));
          }
          else {
            this.isVehicleFound = true;
            //console.log("No Data in get Vehicle!");
          }
        })
  }

  onSelect(fuelTypeId, licensePlateNumber, vehicleId) {
    this.vehicleList.forEach(vehicle =>{
      vehicle.isSelected = false;
    })
    this.vehicleList.find(x => x.VehicleId === vehicleId).isSelected = true;
    this.fuelTypeId = fuelTypeId;
    GlobalVars.fuelTypeId = fuelTypeId;
    GlobalVars.licensePlateNumber = licensePlateNumber;
    GlobalVars.vehicleId = vehicleId;
    //console.log("fuelTypeId : " + fuelTypeId);
  }

  nextclick() {
    GlobalVars.fuelTypeId = this.fuelTypeId;
    //console.log("fuelTypeId var value: ", GlobalVars.fuelTypeId);
    this.router.navigate(['/serviceSelection', this.fuelTypeId])
  }
}
